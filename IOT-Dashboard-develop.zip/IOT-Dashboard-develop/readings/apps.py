from django.apps import AppConfig


class ReadingsConfig(AppConfig):
    name = 'readings'
